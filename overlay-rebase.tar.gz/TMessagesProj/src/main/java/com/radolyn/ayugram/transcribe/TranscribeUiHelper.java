package com.radolyn.ayugram.transcribe;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.MessageObject;
import org.telegram.ui.ActionBar.AlertDialog;
import org.telegram.ui.ActionBar.BaseFragment;

import com.radolyn.ayugram.ui.preferences.AyuGramPreferencesActivity;

import java.io.File;

public class TranscribeUiHelper {
    public static boolean isTranscribable(MessageObject message) {
        return message != null && (message.isVoice() || message.isRoundVideo());
    }

    public static void transcribeAndShow(BaseFragment fragment, int currentAccount, MessageObject message) {
        if (fragment == null || fragment.getParentActivity() == null || message == null) {
            return;
        }
        File audio = LocalTranscribeService.resolveAudioFile(currentAccount, message);
        AlertDialog progress = new AlertDialog.Builder(fragment.getParentActivity())
                .setTitle("Transcribe locally")
                .setMessage("Transcribing…")
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create();
        try {
            fragment.showDialog(progress);
        } catch (Exception ignored) {
            return;
        }
        LocalTranscribeService.transcribe(currentAccount, audio, new LocalTranscribeService.Callback() {
            @Override
            public void onDone(String text) {
                if (fragment.getParentActivity() == null) {
                    return;
                }
                try {
                    progress.dismiss();
                } catch (Exception ignored) {
                }
                CharSequence body = text == null || text.isEmpty() ? "(empty result)" : text;
                AlertDialog.Builder builder = new AlertDialog.Builder(fragment.getParentActivity())
                        .setTitle("Transcribe locally")
                        .setMessage(body)
                        .setPositiveButton("Copy", (dialog, which) -> {
                            AndroidUtilities.addToClipboard(body);
                            dialog.dismiss();
                        })
                        .setNegativeButton("Close", (dialog, which) -> dialog.dismiss());
                try {
                    fragment.showDialog(builder.create());
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onError(int code, String errorMessage) {
                if (fragment.getParentActivity() == null) {
                    return;
                }
                try {
                    progress.dismiss();
                } catch (Exception ignored) {
                }
                if (code == LocalTranscribeService.ERROR_NEEDS_MODEL || code == LocalTranscribeService.ERROR_DISABLED) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(fragment.getParentActivity())
                            .setTitle("Transcribe locally")
                            .setMessage(code == LocalTranscribeService.ERROR_DISABLED
                                    ? "Enable local transcription and download the model first."
                                    : "Transcription model is not downloaded yet.")
                            .setPositiveButton("Open settings", (dialog, which) -> {
                                dialog.dismiss();
                                try {
                                    fragment.presentFragment(new AyuGramPreferencesActivity());
                                } catch (Exception ignored) {
                                }
                            })
                            .setNegativeButton("Close", (dialog, which) -> dialog.dismiss());
                    try {
                        fragment.showDialog(builder.create());
                    } catch (Exception ignored) {
                    }
                    return;
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(fragment.getParentActivity())
                        .setTitle("Transcribe locally")
                        .setMessage(errorMessage != null ? errorMessage : "Transcription failed")
                        .setNegativeButton("Close", (dialog, which) -> dialog.dismiss());
                try {
                    fragment.showDialog(builder.create());
                } catch (Exception ignored) {
                }
            }
        });
    }
}
