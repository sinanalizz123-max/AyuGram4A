/*
 * This is the source code of AyuGram for Android.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright @Radolyn, 2023
 */

package com.radolyn.ayugram.ui.preferences;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.exteragram.messenger.preferences.BasePreferencesActivity;
import com.radolyn.ayugram.AyuConfig;
import com.radolyn.ayugram.AyuConstants;
import com.radolyn.ayugram.ai.AiConfig;
import com.radolyn.ayugram.messages.AyuMessagesController;
import com.radolyn.ayugram.sync.AyuSyncState;
import com.radolyn.ayugram.transcribe.ModelDownloader;
import com.radolyn.ayugram.transcribe.TranscribeConfig;
import com.radolyn.ayugram.ui.preferences.utils.AyuUi;
import com.radolyn.ayugram.utils.AyuState;
import org.jetbrains.annotations.NotNull;
import org.telegram.messenger.*;
import org.telegram.ui.ActionBar.AlertDialog;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Cells.*;
import org.telegram.ui.Components.BulletinFactory;
import org.telegram.ui.Components.RecyclerListView;

import java.io.File;
import java.util.Locale;
import java.util.function.Consumer;
public class AyuGramPreferencesActivity extends BasePreferencesActivity implements NotificationCenter.NotificationCenterDelegate {

    private static final int TOGGLE_BUTTON_VIEW = 1000;

    private int ghostEssentialsHeaderRow;
    private int ghostModeToggleRow;
    private int sendReadPacketsRow;
    private int sendOnlinePacketsRow;
    private int sendUploadProgressRow;
    private int sendOfflinePacketAfterOnlineRow;
    private int markReadAfterSendRow;
    private int useScheduledMessagesRow;
    private int ghostDividerRow;

    private int spyHeaderRow;
    private int saveDeletedMessagesRow;
    private int saveMessagesHistoryRow;
    private int spyDivider1Row;
    private int messageSavingBtnRow;
    private int spyDivider2Row;

    private int qolHeaderRow;
    private int keepAliveServiceRow;
    private int disableAdsRow;
    private int localPremiumRow;
    private int streamerModeRow;
    private int filtersRow;
    private int qolDividerRow;

    private int customizationHeaderRow;
    private int deletedMarkTextRow;
    private int editedMarkTextRow;
    private int showGhostToggleInDrawerRow;
    private int showKillButtonInDrawerRow;
    private int customizationDividerRow;

    private int ayuSyncHeaderRow;
    private int ayuSyncStatusBtnRow;
    private int ayuSyncDividerRow;

    private int aiHeaderRow;
    private int aiProviderRow;
    private int aiKeyRow;
    private int aiModelRow;
    private int aiEndpointRow;
    private int aiDividerRow;

    private int transcribeHeaderRow;
    private int transcribeEnabledRow;
    private int transcribeModelRow;
    private int transcribeModelFileRow;
    private int transcribeDividerRow;

    private int debugHeaderRow;
    private int WALModeRow;
    private int buttonsDividerRow;
    private int clearAyuDatabaseBtnRow;
    private int eraseLocalDatabaseBtnRow;

    private boolean ghostModeMenuExpanded;

    @Override
    protected void updateRowsId() {
        super.updateRowsId();

        ghostEssentialsHeaderRow = newRow();
        ghostModeToggleRow = newRow();
        if (ghostModeMenuExpanded) {
            sendReadPacketsRow = newRow();
            sendOnlinePacketsRow = newRow();
            sendUploadProgressRow = newRow();
            sendOfflinePacketAfterOnlineRow = newRow();
        } else {
            sendReadPacketsRow = -1;
            sendOnlinePacketsRow = -1;
            sendUploadProgressRow = -1;
            sendOfflinePacketAfterOnlineRow = -1;
        }
        markReadAfterSendRow = newRow();
        useScheduledMessagesRow = newRow();
        ghostDividerRow = newRow();

        spyHeaderRow = newRow();
        saveDeletedMessagesRow = newRow();
        saveMessagesHistoryRow = newRow();
        spyDivider1Row = newRow();
        messageSavingBtnRow = newRow();
        spyDivider2Row = newRow();

        qolHeaderRow = newRow();
        keepAliveServiceRow = newRow();
        disableAdsRow = newRow();
        localPremiumRow = newRow();
        streamerModeRow = newRow();
        filtersRow = newRow();
        qolDividerRow = newRow();

        customizationHeaderRow = newRow();
        deletedMarkTextRow = newRow();
        editedMarkTextRow = newRow();
        showGhostToggleInDrawerRow = newRow();
        showKillButtonInDrawerRow = newRow();
        customizationDividerRow = newRow();

        ayuSyncHeaderRow = newRow();
        ayuSyncStatusBtnRow = newRow();
        ayuSyncDividerRow = newRow();

        aiHeaderRow = newRow();
        aiProviderRow = newRow();
        aiKeyRow = newRow();
        aiModelRow = newRow();
        aiEndpointRow = newRow();
        aiDividerRow = newRow();

        transcribeHeaderRow = newRow();
        transcribeEnabledRow = newRow();
        transcribeModelRow = newRow();
        transcribeModelFileRow = newRow();
        transcribeDividerRow = newRow();

        debugHeaderRow = newRow();
        WALModeRow = newRow();
        buttonsDividerRow = newRow();
        clearAyuDatabaseBtnRow = newRow();
        eraseLocalDatabaseBtnRow = newRow();
    }

    @Override
    public boolean onFragmentCreate() {
        super.onFragmentCreate();
        // todo: register `MESSAGES_DELETED_NOTIFICATION` on all notification centers, not only on the current account

        NotificationCenter.getInstance(UserConfig.selectedAccount).addObserver(this, AyuConstants.MESSAGES_DELETED_NOTIFICATION);
        NotificationCenter.getGlobalInstance().addObserver(this, AyuConstants.AYUSYNC_STATE_CHANGED);

        return true;
    }

    @Override
    public void didReceivedNotification(int id, int account, Object... args) {
        if (id == AyuConstants.MESSAGES_DELETED_NOTIFICATION) {
            // recalculate database size
            if (listAdapter != null) {
                listAdapter.notifyItemChanged(clearAyuDatabaseBtnRow);
            }
        } else if (id == AyuConstants.AYUSYNC_STATE_CHANGED) {
            if (listAdapter != null) {
                listAdapter.notifyItemChanged(ayuSyncStatusBtnRow);
            }
        }
    }

    @Override
    public void onFragmentDestroy() {
        super.onFragmentDestroy();

        NotificationCenter.getInstance(UserConfig.selectedAccount).removeObserver(this, AyuConstants.MESSAGES_DELETED_NOTIFICATION);
        NotificationCenter.getGlobalInstance().removeObserver(this, AyuConstants.AYUSYNC_STATE_CHANGED);
    }

    private void updateGhostViews() {
        boolean isActive = AyuConfig.isGhostModeActive();

        listAdapter.notifyItemChanged(ghostModeToggleRow, payload);
        listAdapter.notifyItemChanged(sendReadPacketsRow, !isActive);
        listAdapter.notifyItemChanged(sendOnlinePacketsRow, !isActive);
        listAdapter.notifyItemChanged(sendUploadProgressRow, !isActive);
        listAdapter.notifyItemChanged(sendOfflinePacketAfterOnlineRow, isActive);

        NotificationCenter.getInstance(UserConfig.selectedAccount).postNotificationName(NotificationCenter.mainUserInfoChanged);
    }

    private void toggleLocalPremium() {
        boolean newState = !AyuConfig.localPremium;

        AyuConfig.editor.putBoolean("localPremium", AyuConfig.localPremium = newState).apply();
        listAdapter.notifyItemChanged(localPremiumRow, AyuConfig.localPremium);

        getMessagesController().updatePremium(AyuConfig.localPremium);
        NotificationCenter.getInstance(currentAccount).postNotificationName(NotificationCenter.currentUserPremiumStatusChanged);
        NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.premiumStatusChangedGlobal);

        getMediaDataController().loadPremiumPromo(false);
        getMediaDataController().loadReactions(false, true);
    }

    private void onTranscribeModelFileClick(TextCell view) {
        if (getParentActivity() == null) {
            return;
        }
        File modelFile = TranscribeConfig.getModelFile(getParentActivity());
        if (modelFile.exists() && modelFile.length() > 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getParentActivity());
            builder.setTitle("Transcription model");
            builder.setMessage("Delete downloaded model (" + AndroidUtilities.formatFileSize(modelFile.length()) + ")?");
            builder.setPositiveButton(LocaleController.getString("Delete", R.string.Delete), (dialog, which) -> {
                modelFile.delete();
                listAdapter.notifyItemChanged(transcribeModelFileRow);
                dialog.dismiss();
            });
            builder.setNegativeButton(LocaleController.getString("Cancel", R.string.Cancel), (dialog, which) -> dialog.dismiss());
            builder.show();
            return;
        }
        TranscribeConfig.ModelVariant variant = TranscribeConfig.modelVariant;
        String url = TranscribeConfig.getModelUrl(variant);
        AlertDialog progress = new AlertDialog.Builder(getParentActivity())
                .setTitle("Transcription model")
                .setMessage("Downloading… 0%")
                .setNegativeButton(LocaleController.getString("Cancel", R.string.Cancel), (dialog, which) -> dialog.dismiss())
                .create();
        progress.show();
        ModelDownloader.download(getParentActivity(), url, modelFile, null, new ModelDownloader.ProgressCallback() {
            @Override
            public void onProgress(long downloadedBytes, long totalBytes) {
                try {
                    if (totalBytes > 0) {
                        progress.setMessage("Downloading… " + (downloadedBytes * 100 / totalBytes) + "%");
                    } else {
                        progress.setMessage("Downloading… " + AndroidUtilities.formatFileSize(downloadedBytes));
                    }
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onDone(File file) {
                try {
                    progress.dismiss();
                } catch (Exception ignored) {
                }
                listAdapter.notifyItemChanged(transcribeModelFileRow);
                BulletinFactory.of(AyuGramPreferencesActivity.this).createSimpleBulletin(R.raw.info, "Model downloaded").show();
            }

            @Override
            public void onError(String error) {
                try {
                    progress.dismiss();
                } catch (Exception ignored) {
                }
                BulletinFactory.of(AyuGramPreferencesActivity.this).createSimpleBulletin(R.raw.error, error != null ? error : "Download failed").show();
            }
        });
    }

    private void spawnAiEditBox(String title, String current, Consumer<String> saver, int row) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getParentActivity());
        builder.setTitle(title);
        LinearLayout layout = new LinearLayout(getParentActivity());
        EditTextSettingsCell input = new EditTextSettingsCell(getParentActivity());
        input.setText(current != null ? current : "", true);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(input);
        builder.setView(layout);
        builder.setPositiveButton(LocaleController.getString("Save", R.string.Save), (dialog, which) -> {
            String s = input.getText().trim();
            saver.accept(s);
            listAdapter.notifyItemChanged(row);
        });
        builder.setNegativeButton(LocaleController.getString("Cancel", R.string.Cancel), (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    @Override
    protected void onItemClick(View view, int position, float x, float y) {
        if (position == ghostModeToggleRow) {
            ghostModeMenuExpanded ^= true;
            updateRowsId();
            listAdapter.notifyItemChanged(ghostModeToggleRow, payload);
            if (ghostModeMenuExpanded) {
                listAdapter.notifyItemRangeInserted(ghostModeToggleRow + 1, 4);
            } else {
                listAdapter.notifyItemRangeRemoved(ghostModeToggleRow + 1, 4);
            }
        } else if (position == sendReadPacketsRow) {
            AyuConfig.editor.putBoolean("sendReadPackets", AyuConfig.sendReadPackets ^= true).apply();
            ((CheckBoxCell) view).setChecked(AyuConfig.sendReadPackets, true);

            AyuState.setAllowReadPacket(false, -1);
            updateGhostViews();
        } else if (position == sendOnlinePacketsRow) {
            AyuConfig.editor.putBoolean("sendOnlinePackets", AyuConfig.sendOnlinePackets ^= true).apply();
            ((CheckBoxCell) view).setChecked(AyuConfig.sendOnlinePackets, true);

            updateGhostViews();
        } else if (position == sendUploadProgressRow) {
            AyuConfig.editor.putBoolean("sendUploadProgress", AyuConfig.sendUploadProgress ^= true).apply();
            ((CheckBoxCell) view).setChecked(AyuConfig.sendUploadProgress, true);

            updateGhostViews();
        } else if (position == sendOfflinePacketAfterOnlineRow) {
            AyuConfig.editor.putBoolean("sendOfflinePacketAfterOnline", AyuConfig.sendOfflinePacketAfterOnline ^= true).apply();
            ((CheckBoxCell) view).setChecked(AyuConfig.sendOfflinePacketAfterOnline, true);

            updateGhostViews();
        } else if (position == markReadAfterSendRow) {
            AyuConfig.editor.putBoolean("markReadAfterSend", AyuConfig.markReadAfterSend ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.markReadAfterSend);

            AyuState.setAllowReadPacket(false, -1);

            if (AyuConfig.markReadAfterSend && AyuConfig.useScheduledMessages) {
                AyuConfig.editor.putBoolean("useScheduledMessages", AyuConfig.useScheduledMessages ^= true).apply();

                listAdapter.notifyItemChanged(useScheduledMessagesRow, false);
            }
        } else if (position == useScheduledMessagesRow) {
            AyuConfig.editor.putBoolean("useScheduledMessages", AyuConfig.useScheduledMessages ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.useScheduledMessages);

            AyuState.setAutomaticallyScheduled(false, -1);

            if (AyuConfig.useScheduledMessages && AyuConfig.markReadAfterSend) {
                AyuConfig.editor.putBoolean("markReadAfterSend", AyuConfig.markReadAfterSend ^= true).apply();

                listAdapter.notifyItemChanged(markReadAfterSendRow, false);
            }
        } else if (position == saveDeletedMessagesRow) {
            AyuConfig.editor.putBoolean("saveDeletedMessages", AyuConfig.saveDeletedMessages ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.saveDeletedMessages);
        } else if (position == saveMessagesHistoryRow) {
            AyuConfig.editor.putBoolean("saveMessagesHistory", AyuConfig.saveMessagesHistory ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.saveMessagesHistory);
        } else if (position == messageSavingBtnRow) {
            presentFragment(new MessageSavingPreferencesActivity());
        } else if (position == keepAliveServiceRow) {
            AyuConfig.editor.putBoolean("keepAliveService", AyuConfig.keepAliveService ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.keepAliveService);
        } else if (position == disableAdsRow) {
            AyuConfig.editor.putBoolean("disableAds", AyuConfig.disableAds ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.disableAds);
        } else if (position == localPremiumRow) {
            toggleLocalPremium();
        } else if (position == streamerModeRow) {
            AyuConfig.setStreamerMode(!AyuConfig.streamerMode);
            ((TextCheckCell) view).setChecked(AyuConfig.streamerMode);
            BaseFragment.applyStreamerMode(getParentActivity());
        } else if (position == filtersRow) {
            NotificationsCheckCell checkCell = (NotificationsCheckCell) view;
            if (LocaleController.isRTL && x <= AndroidUtilities.dp(76) || !LocaleController.isRTL && x >= view.getMeasuredWidth() - AndroidUtilities.dp(76)) {
                AyuConfig.editor.putBoolean("regexFiltersEnabled", AyuConfig.regexFiltersEnabled ^= true).apply();
                checkCell.setChecked(AyuConfig.regexFiltersEnabled, 0);
            } else {
                presentFragment(new RegexFiltersPreferencesActivity());
            }
        } else if (position == showGhostToggleInDrawerRow) {
            AyuConfig.editor.putBoolean("showGhostToggleInDrawer", AyuConfig.showGhostToggleInDrawer ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.showGhostToggleInDrawer);

            NotificationCenter.getInstance(UserConfig.selectedAccount).postNotificationName(NotificationCenter.mainUserInfoChanged);
        } else if (position == showKillButtonInDrawerRow) {
            AyuConfig.editor.putBoolean("showKillButtonInDrawer", AyuConfig.showKillButtonInDrawer ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.showKillButtonInDrawer);

            NotificationCenter.getInstance(UserConfig.selectedAccount).postNotificationName(NotificationCenter.mainUserInfoChanged);
        } else if (position == deletedMarkTextRow) {
            AyuUi.spawnEditBox(
                    getParentActivity(),
                    ((TextCell) view),
                    LocaleController.getString(R.string.DeletedMarkText),
                    AyuConfig::getDeletedMark,
                    "deletedMarkText",
                    AyuConstants.DEFAULT_DELETED_MARK
            );
        } else if (position == editedMarkTextRow) {
            AyuUi.spawnEditBox(
                    getParentActivity(),
                    ((TextCell) view),
                    LocaleController.getString(R.string.EditedMarkText),
                    AyuConfig::getEditedMark,
                    "editedMarkText",
                    LocaleController.getString("EditedMessage", R.string.EditedMessage) // don't remove key
            );
        } else if (position == ayuSyncStatusBtnRow) {
            presentFragment(new AyuSyncPreferencesActivity());
        } else if (position == aiProviderRow) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getParentActivity());
            builder.setTitle("AI Provider");
            CharSequence[] providers = {"Gemini", "OpenRouter", "Custom"};
            builder.setItems(providers, (dialog, which) -> {
                AiConfig.Provider p = which == 1 ? AiConfig.Provider.OPENROUTER : which == 2 ? AiConfig.Provider.CUSTOM : AiConfig.Provider.GEMINI;
                AiConfig.setProvider(p);
                listAdapter.notifyItemChanged(aiProviderRow);
                listAdapter.notifyItemChanged(aiModelRow);
                listAdapter.notifyItemChanged(aiEndpointRow);
            });
            builder.setNegativeButton(LocaleController.getString("Cancel", R.string.Cancel), (dialog, which) -> dialog.dismiss());
            builder.show();
        } else if (position == aiKeyRow) {
            spawnAiEditBox("AI API Key", AiConfig.apiKey, AiConfig::setApiKey, aiKeyRow);
        } else if (position == aiModelRow) {
            spawnAiEditBox("AI Model", AiConfig.model, AiConfig::setModel, aiModelRow);
        } else if (position == aiEndpointRow) {
            spawnAiEditBox("AI Endpoint", AiConfig.endpoint, AiConfig::setEndpoint, aiEndpointRow);
        } else if (position == transcribeEnabledRow) {
            TranscribeConfig.setEnabled(!TranscribeConfig.enabled);
            ((TextCheckCell) view).setChecked(TranscribeConfig.enabled);
        } else if (position == transcribeModelRow) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getParentActivity());
            builder.setTitle("Transcription model");
            CharSequence[] variants = {"tiny", "base"};
            builder.setItems(variants, (dialog, which) -> {
                TranscribeConfig.setModelVariant(which == 1 ? TranscribeConfig.ModelVariant.BASE : TranscribeConfig.ModelVariant.TINY);
                listAdapter.notifyItemChanged(transcribeModelRow);
                listAdapter.notifyItemChanged(transcribeModelFileRow);
            });
            builder.setNegativeButton(LocaleController.getString("Cancel", R.string.Cancel), (dialog, which) -> dialog.dismiss());
            builder.show();
        } else if (position == transcribeModelFileRow) {
            onTranscribeModelFileClick((TextCell) view);
        } else if (position == WALModeRow) {
            AyuConfig.editor.putBoolean("WALMode", AyuConfig.WALMode ^= true).apply();
            ((TextCheckCell) view).setChecked(AyuConfig.WALMode);
        } else if (position == clearAyuDatabaseBtnRow) {
            AyuMessagesController.getInstance().clean();

            // reset size
            ((TextCell) view).setValue("…");

            BulletinFactory.of(this).createSimpleBulletin(R.raw.info, LocaleController.getString(R.string.ClearAyuDatabaseNotification)).show();
        } else if (position == eraseLocalDatabaseBtnRow) {
            getMessagesStorage().clearLocalDatabase();

            try {
                getMessagesStorage().getDatabase().executeFast("DELETE FROM messages_v2").stepThis().dispose();
            } catch (Exception e) {
                FileLog.e(e);
                BulletinFactory.of(this).createSimpleBulletin(R.raw.error, LocaleController.getString(R.string.ErrorOccurred)).show();
            }

            try {
                getMessagesStorage().getDatabase().executeFast("DELETE FROM dialogs").stepThis().dispose();
            } catch (Exception e) {
                FileLog.e(e);
                BulletinFactory.of(this).createSimpleBulletin(R.raw.error, LocaleController.getString(R.string.ErrorOccurred)).show();
            }

            BulletinFactory.of(this).createSimpleBulletin(R.raw.info, LocaleController.getString(R.string.RestartRequired)).show();
        }
    }

    @Override
    protected String getTitle() {
        return LocaleController.getString(R.string.AyuPreferences);
    }

    @Override
    protected BaseListAdapter createAdapter(Context context) {
        return new ListAdapter(context);
    }

    private int getGhostModeSelectedCount() {
        int count = 0;
        if (!AyuConfig.sendReadPackets) count++;
        if (!AyuConfig.sendOnlinePackets) count++;
        if (!AyuConfig.sendUploadProgress) count++;
        if (AyuConfig.sendOfflinePacketAfterOnline) count++;

        return count;
    }

    private class ListAdapter extends BaseListAdapter {

        public ListAdapter(Context context) {
            super(context);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, boolean payload) {
            switch (holder.getItemViewType()) {
                case 1:
                    holder.itemView.setBackground(Theme.getThemedDrawable(mContext, R.drawable.greydivider, Theme.key_windowBackgroundGrayShadow));
                    break;
                case 2:
                    TextCell textCell = (TextCell) holder.itemView;
                    textCell.setTextColor(Theme.getColor(Theme.key_windowBackgroundWhiteBlackText));
                    if (position == messageSavingBtnRow) {
                        textCell.setText(LocaleController.getString(R.string.MessageSavingBtn), false);
                    } else if (position == deletedMarkTextRow) {
                        textCell.setTextAndValue(LocaleController.getString(R.string.DeletedMarkText), AyuConfig.getDeletedMark(), true);
                    } else if (position == editedMarkTextRow) {
                        textCell.setTextAndValue(LocaleController.getString(R.string.EditedMarkText), AyuConfig.getEditedMark(), true);
                    } else if (position == ayuSyncStatusBtnRow) {
                        String status = AyuSyncState.getConnectionStateString();

                        textCell.setTextAndValue(LocaleController.getString(R.string.AyuSyncStatusTitle), status, false);
                    } else if (position == aiProviderRow) {
                        textCell.setTextAndValue("AI Provider", AiConfig.getProviderName(), true);
                    } else if (position == aiKeyRow) {
                        textCell.setTextAndValue("AI API Key", AiConfig.keyStatus(), true);
                    } else if (position == aiModelRow) {
                        String m = TextUtils.isEmpty(AiConfig.model) ? AiConfig.getEffectiveModel() : AiConfig.model;
                        textCell.setTextAndValue("AI Model", TextUtils.isEmpty(m) ? "Not set" : m, true);
                    } else if (position == aiEndpointRow) {
                        String e = TextUtils.isEmpty(AiConfig.endpoint) ? AiConfig.getEffectiveEndpoint() : AiConfig.endpoint;
                        textCell.setTextAndValue("AI Endpoint", TextUtils.isEmpty(e) ? "Not set" : e, false);
                    } else if (position == transcribeModelRow) {
                        textCell.setTextAndValue("Transcription model", TranscribeConfig.modelVariant.id, true);
                    } else if (position == transcribeModelFileRow) {
                        File modelFile = TranscribeConfig.getModelFile(mContext);
                        if (modelFile.exists() && modelFile.length() > 0) {
                            textCell.setTextAndValue("Model file", "Downloaded (" + AndroidUtilities.formatFileSize(modelFile.length()) + ")", false);
                        } else {
                            textCell.setTextAndValue("Model file", "Not downloaded", false);
                        }
                    } else if (position == clearAyuDatabaseBtnRow) {
                        File file = ApplicationLoader.applicationContext.getDatabasePath(AyuConstants.AYU_DATABASE);
                        long size = file.exists() ? file.length() : 0;

                        textCell.setTextAndValueAndIcon(LocaleController.getString(R.string.ClearAyuDatabase), AndroidUtilities.formatFileSize(size), R.drawable.msg_clear_solar, true);
                        textCell.setColors(Theme.key_text_RedBold, Theme.key_text_RedBold);
                    } else if (position == eraseLocalDatabaseBtnRow) {
                        textCell.setTextAndIcon(LocaleController.getString(R.string.EraseLocalDatabase), R.drawable.msg_archive, false);
                        textCell.setColors(Theme.key_text_RedBold, Theme.key_text_RedBold);
                    }
                    break;
                case 3:
                    HeaderCell headerCell = (HeaderCell) holder.itemView;
                    if (position == ghostEssentialsHeaderRow) {
                        headerCell.setText(LocaleController.getString(R.string.GhostEssentialsHeader));
                    } else if (position == spyHeaderRow) {
                        headerCell.setText(LocaleController.getString(R.string.SpyEssentialsHeader));
                    } else if (position == qolHeaderRow) {
                        headerCell.setText(LocaleController.getString(R.string.QoLTogglesHeader));
                    } else if (position == customizationHeaderRow) {
                        headerCell.setText(LocaleController.getString(R.string.CustomizationHeader));
                    } else if (position == ayuSyncHeaderRow) {
                        headerCell.setText(LocaleController.getString(R.string.AyuSyncHeader));
                    } else if (position == aiHeaderRow) {
                        headerCell.setText("AI Assistant");
                    } else if (position == transcribeHeaderRow) {
                        headerCell.setText("Local transcription");
                    } else if (position == debugHeaderRow) {
                        headerCell.setText(LocaleController.getString("SettingsDebug", R.string.SettingsDebug));
                    }
                    break;
                case 5:
                    TextCheckCell textCheckCell = (TextCheckCell) holder.itemView;
                    textCheckCell.setEnabled(true, null);
                    if (position == markReadAfterSendRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.MarkReadAfterSend), AyuConfig.markReadAfterSend, true);
                    } else if (position == useScheduledMessagesRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.UseScheduledMessages), AyuConfig.useScheduledMessages, false);
                    } else if (position == saveDeletedMessagesRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.SaveDeletedMessages), AyuConfig.saveDeletedMessages, true);
                    } else if (position == saveMessagesHistoryRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.SaveMessagesHistory), AyuConfig.saveMessagesHistory, false);
                    } else if (position == keepAliveServiceRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.KeepAliveService), AyuConfig.keepAliveService, true);
                    } else if (position == disableAdsRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.DisableAds), AyuConfig.disableAds, true);
                    } else if (position == localPremiumRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.LocalPremium) + " β", AyuConfig.localPremium, true);
                    } else if (position == streamerModeRow) {
                        textCheckCell.setTextAndCheck("Streamer Mode", AyuConfig.streamerMode, true);
                    } else if (position == transcribeEnabledRow) {
                        textCheckCell.setTextAndCheck("Enable local transcription", TranscribeConfig.enabled, false);
                    } else if (position == showGhostToggleInDrawerRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.ShowGhostToggleInDrawer), AyuConfig.showGhostToggleInDrawer, true);
                    } else if (position == showKillButtonInDrawerRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.ShowKllButtonInDrawer), AyuConfig.showKillButtonInDrawer, false);
                    } else if (position == WALModeRow) {
                        textCheckCell.setTextAndCheck(LocaleController.getString(R.string.WALMode), AyuConfig.WALMode, false);
                    }
                    break;
                case 18:
                    TextCheckCell2 checkCell = (TextCheckCell2) holder.itemView;
                    if (position == ghostModeToggleRow) {
                        int selectedCount = getGhostModeSelectedCount();
                        checkCell.setTextAndCheck(LocaleController.getString(R.string.GhostModeToggle), AyuConfig.isGhostModeActive(), true, true);
                        checkCell.setCollapseArrow(String.format(Locale.US, "%d/4", selectedCount), !ghostModeMenuExpanded, () -> {
                            AyuConfig.toggleGhostMode();
                            updateGhostViews();
                        });
                    }
                    checkCell.getCheckBox().setColors(Theme.key_switchTrack, Theme.key_switchTrackChecked, Theme.key_windowBackgroundWhite, Theme.key_windowBackgroundWhite);
                    checkCell.getCheckBox().setDrawIconType(0);
                    break;
                case 19:
                    CheckBoxCell checkBoxCell = (CheckBoxCell) holder.itemView;
                    if (position == sendReadPacketsRow) {
                        checkBoxCell.setText(LocaleController.getString(R.string.DontSendReadPackets), "", !AyuConfig.sendReadPackets, true, true);
                    } else if (position == sendOnlinePacketsRow) {
                        checkBoxCell.setText(LocaleController.getString(R.string.DontSendOnlinePackets), "", !AyuConfig.sendOnlinePackets, true, true);
                    } else if (position == sendUploadProgressRow) {
                        checkBoxCell.setText(LocaleController.getString(R.string.DontSendUploadProgress), "", !AyuConfig.sendUploadProgress, true, true);
                    } else if (position == sendOfflinePacketAfterOnlineRow) {
                        checkBoxCell.setText(LocaleController.getString(R.string.SendOfflinePacketAfterOnline), "", AyuConfig.sendOfflinePacketAfterOnline, true, true);
                    }
                    checkBoxCell.setPad(1);
                    break;
                case TOGGLE_BUTTON_VIEW:
                    NotificationsCheckCell notificationsCheckCell = (NotificationsCheckCell) holder.itemView;
                    if (position == filtersRow) {
                        int count = AyuConfig.getRegexFilters().size();
                        notificationsCheckCell.setTextAndValueAndCheck(LocaleController.getString(R.string.RegexFilters), count + " " + LocaleController.getString(R.string.RegexFiltersAmount), AyuConfig.regexFiltersEnabled, false);
                    }
                    break;
            }
        }

        @NonNull
        @NotNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
            if (viewType == TOGGLE_BUTTON_VIEW) {
                NotificationsCheckCell view = new NotificationsCheckCell(mContext);
                view.setBackgroundColor(Theme.getColor(Theme.key_windowBackgroundWhite));
                return new RecyclerListView.Holder(view);
            }
            return super.onCreateViewHolder(parent, viewType);
        }

        @Override
        public int getItemViewType(int position) {
            if (
                    position == ghostDividerRow ||
                            position == spyDivider1Row ||
                            position == spyDivider2Row ||
                            position == qolDividerRow ||
                            position == customizationDividerRow ||
                            position == ayuSyncDividerRow ||
                            position == aiDividerRow ||
                            position == transcribeDividerRow ||
                            position == buttonsDividerRow
            ) {
                return 1;
            } else if (
                    position == messageSavingBtnRow ||
                            position == deletedMarkTextRow ||
                            position == editedMarkTextRow ||
                            position == ayuSyncStatusBtnRow ||
                            position == aiProviderRow ||
                            position == aiKeyRow ||
                            position == aiModelRow ||
                            position == aiEndpointRow ||
                            position == transcribeModelRow ||
                            position == transcribeModelFileRow ||
                            position == clearAyuDatabaseBtnRow ||
                            position == eraseLocalDatabaseBtnRow
            ) {
                return 2;
            } else if (
                    position == ghostEssentialsHeaderRow ||
                            position == spyHeaderRow ||
                            position == qolHeaderRow ||
                            position == customizationHeaderRow ||
                            position == ayuSyncHeaderRow ||
                            position == aiHeaderRow ||
                            position == transcribeHeaderRow ||
                            position == debugHeaderRow
            ) {
                return 3;
            } else if (
                    position == ghostModeToggleRow
            ) {
                return 18;
            } else if (
                    position >= sendReadPacketsRow && position <= sendOfflinePacketAfterOnlineRow
            ) {
                return 19;
            } else if (
                    position == filtersRow
            ) {
                return TOGGLE_BUTTON_VIEW;
            }
            return 5;
        }
    }
}
