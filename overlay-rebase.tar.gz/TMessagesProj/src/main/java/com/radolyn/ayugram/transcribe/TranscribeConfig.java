package com.radolyn.ayugram.transcribe;

import android.content.Context;
import android.content.SharedPreferences;

import org.telegram.messenger.ApplicationLoader;

import java.io.File;

public class TranscribeConfig {
    private static final String PREFS = "ayutranscribe";

    public enum ModelVariant {
        TINY("tiny", "ggml-tiny.bin", "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin"),
        BASE("base", "ggml-base.bin", "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin");

        public final String id;
        public final String fileName;
        public final String defaultUrl;

        ModelVariant(String id, String fileName, String defaultUrl) {
            this.id = id;
            this.fileName = fileName;
            this.defaultUrl = defaultUrl;
        }

        public static ModelVariant fromId(String id) {
            for (ModelVariant v : values()) {
                if (v.id.equals(id)) {
                    return v;
                }
            }
            return TINY;
        }
    }

    public static boolean enabled = false;
    public static ModelVariant modelVariant = ModelVariant.TINY;

    private static SharedPreferences prefs;
    private static boolean loaded;

    private static synchronized void ensureLoaded() {
        if (loaded) {
            return;
        }
        try {
            Context ctx = ApplicationLoader.applicationContext;
            if (ctx == null) {
                return;
            }
            prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            enabled = prefs.getBoolean("enabled", false);
            modelVariant = ModelVariant.fromId(prefs.getString("modelVariant", ModelVariant.TINY.id));
        } catch (Exception ignored) {
        }
        loaded = true;
    }

    public static void setEnabled(boolean value) {
        ensureLoaded();
        enabled = value;
        if (prefs != null) {
            prefs.edit().putBoolean("enabled", value).apply();
        }
    }

    public static void setModelVariant(ModelVariant variant) {
        ensureLoaded();
        if (variant == null) {
            return;
        }
        modelVariant = variant;
        if (prefs != null) {
            prefs.edit().putString("modelVariant", variant.id).apply();
        }
    }

    public static String getModelUrl(ModelVariant variant) {
        ensureLoaded();
        if (prefs != null) {
            String custom = prefs.getString("modelUrl_" + variant.id, null);
            if (custom != null && !custom.isEmpty()) {
                return custom;
            }
        }
        return variant.defaultUrl;
    }

    public static void setModelUrl(ModelVariant variant, String url) {
        ensureLoaded();
        if (prefs != null) {
            prefs.edit().putString("modelUrl_" + variant.id, url).apply();
        }
    }

    public static File getModelDir(Context ctx) {
        Context c = ctx != null ? ctx : ApplicationLoader.applicationContext;
        return new File(c.getFilesDir(), "transcribe");
    }

    public static File getModelFile(Context ctx, ModelVariant variant) {
        return new File(getModelDir(ctx), variant.fileName);
    }

    public static File getModelFile(Context ctx) {
        ensureLoaded();
        return getModelFile(ctx, modelVariant);
    }

    public static boolean isModelPresent(Context ctx) {
        File f = getModelFile(ctx);
        return f != null && f.exists() && f.length() > 0;
    }
}
