package com.radolyn.ayugram.transcribe;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.FileLoader;
import org.telegram.messenger.FileLog;
import org.telegram.messenger.MessageObject;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalTranscribeService {
    public static final int ERROR_NEEDS_MODEL = 1;
    public static final int ERROR_NO_ENGINE = 2;
    public static final int ERROR_DISABLED = 3;
    public static final int ERROR_FAILED = 4;

    public interface Callback {
        void onDone(String text);

        void onError(int code, String message);
    }

    private static final ExecutorService queue = Executors.newSingleThreadExecutor();
    private static volatile TranscribeEngine engine;

    public static void setEngine(TranscribeEngine value) {
        engine = value;
    }

    public static TranscribeEngine getEngine() {
        return engine;
    }

    public static File resolveAudioFile(int currentAccount, MessageObject message) {
        if (message == null || message.messageOwner == null) {
            return null;
        }
        String attachPath = message.messageOwner.attachPath;
        if (attachPath != null && !attachPath.isEmpty()) {
            File f = new File(attachPath);
            if (f.exists()) {
                return f;
            }
        }
        try {
            File f = FileLoader.getInstance(currentAccount).getPathToMessage(message.messageOwner);
            if (f != null && f.exists()) {
                return f;
            }
        } catch (Exception e) {
            FileLog.e(e);
        }
        return null;
    }

    public static void transcribe(int currentAccount, MessageObject message, Callback callback) {
        transcribe(currentAccount, resolveAudioFile(currentAccount, message), callback);
    }

    public static void transcribe(int currentAccount, File audio, Callback callback) {
        if (!TranscribeConfig.enabled) {
            postError(callback, ERROR_DISABLED, "Local transcription is disabled");
            return;
        }
        if (audio == null || !audio.exists()) {
            postError(callback, ERROR_FAILED, "Audio file not downloaded yet");
            return;
        }
        if (!TranscribeConfig.isModelPresent(null)) {
            postError(callback, ERROR_NEEDS_MODEL, "Transcription model is not downloaded");
            return;
        }
        TranscribeEngine e = engine;
        if (e == null || !e.isAvailable()) {
            postError(callback, ERROR_NO_ENGINE, "Transcription engine is not available");
            return;
        }
        queue.execute(() -> {
            try {
                String text = e.transcribe(audio);
                if (text == null) {
                    text = "";
                }
                String result = text;
                AndroidUtilities.runOnUIThread(() -> callback.onDone(result));
            } catch (Exception ex) {
                FileLog.e(ex);
                postError(callback, ERROR_FAILED, ex.getMessage());
            }
        });
    }

    private static void postError(Callback callback, int code, String message) {
        if (callback == null) {
            return;
        }
        AndroidUtilities.runOnUIThread(() -> callback.onError(code, message));
    }
}
