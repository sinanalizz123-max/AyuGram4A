package com.radolyn.ayugram.ai;

import android.app.Activity;
import android.text.TextUtils;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.MessageObject;
import org.telegram.ui.ActionBar.AlertDialog;

import java.util.List;

public class AiActions {
    private interface Task {
        void run(AiClient.Callback callback);
    }

    public static String extractText(MessageObject message) {
        if (message == null) {
            return "";
        }
        if (!TextUtils.isEmpty(message.caption)) {
            return message.caption.toString();
        }
        if (message.messageText != null && !TextUtils.isEmpty(message.messageText.toString())) {
            return message.messageText.toString();
        }
        return "";
    }

    public static void summarize(String text, AiClient.Callback callback) {
        if (!AiConfig.isConfigured()) {
            callback.onError("AI key is not configured. Set it in AyuGram settings.");
            return;
        }
        if (TextUtils.isEmpty(text != null ? text.trim() : null)) {
            callback.onError("Nothing to summarize.");
            return;
        }
        AiClient.complete("Summarize the following message concisely:\n\n" + text, callback);
    }

    public static void translate(String text, String targetLang, AiClient.Callback callback) {
        if (!AiConfig.isConfigured()) {
            callback.onError("AI key is not configured. Set it in AyuGram settings.");
            return;
        }
        if (TextUtils.isEmpty(text != null ? text.trim() : null)) {
            callback.onError("Nothing to translate.");
            return;
        }
        String lang = TextUtils.isEmpty(targetLang) ? "English" : targetLang;
        AiClient.complete("Translate the following message to " + lang + ". Reply with the translation only:\n\n" + text, callback);
    }

    public static void replyDraft(List<String> messages, AiClient.Callback callback) {
        if (!AiConfig.isConfigured()) {
            callback.onError("AI key is not configured. Set it in AyuGram settings.");
            return;
        }
        if (messages == null || messages.isEmpty()) {
            callback.onError("No messages to reply to.");
            return;
        }
        StringBuilder prompt = new StringBuilder("Draft a short, friendly reply to the following message(s). Reply with the draft only:\n");
        boolean any = false;
        for (String m : messages) {
            if (!TextUtils.isEmpty(m)) {
                prompt.append("\n- ").append(m);
                any = true;
            }
        }
        if (!any) {
            callback.onError("No messages to reply to.");
            return;
        }
        AiClient.complete(prompt.toString(), callback);
    }

    public static void summarizeFlow(Activity activity, String text) {
        runFlow(activity, "AI Summary", callback -> summarize(text, callback));
    }

    public static void translateFlow(Activity activity, String text, String targetLang) {
        runFlow(activity, "AI Translation", callback -> translate(text, targetLang, callback));
    }

    public static void draftFlow(Activity activity, List<String> messages) {
        runFlow(activity, "AI Draft Reply", callback -> replyDraft(messages, callback));
    }

    private static void runFlow(Activity activity, String title, Task task) {
        if (activity == null || activity.isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(title);
        builder.setMessage("Please wait…");
        final AlertDialog progress = builder.create();
        try {
            progress.show();
        } catch (Exception e) {
            return;
        }
        task.run(new AiClient.Callback() {
            @Override
            public void onResult(String text) {
                AndroidUtilities.runOnUIThread(() -> {
                    try {
                        progress.dismiss();
                    } catch (Exception e) {
                    }
                    showResult(activity, title, text);
                });
            }

            @Override
            public void onError(String error) {
                AndroidUtilities.runOnUIThread(() -> {
                    try {
                        progress.dismiss();
                    } catch (Exception e) {
                    }
                    showResult(activity, title, error);
                });
            }
        });
    }

    public static void showResult(Activity activity, String title, String text) {
        if (activity == null || activity.isFinishing()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(title);
        builder.setMessage(!TextUtils.isEmpty(text) ? text : "Empty response.");
        final String copy = !TextUtils.isEmpty(text) ? text : "";
        builder.setPositiveButton("Copy", (dialog, which) -> AndroidUtilities.addToClipboard(copy));
        builder.setNegativeButton("Close", (dialog, which) -> dialog.dismiss());
        try {
            builder.show();
        } catch (Exception e) {
        }
    }
}
