package com.radolyn.ayugram.ai;

import android.app.Activity;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.telegram.messenger.ApplicationLoader;

public class AiConfig {
    public enum Provider {
        GEMINI,
        OPENROUTER,
        CUSTOM
    }

    private static final String PREFS_NAME = "ayu_ai";

    private static final String DEFAULT_GEMINI_MODEL = "gemini-1.5-flash";
    private static final String DEFAULT_OPENROUTER_MODEL = "openai/gpt-4o-mini";
    private static final String DEFAULT_OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions";
    private static final String GEMINI_ENDPOINT_TEMPLATE = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent";

    public static Provider provider = Provider.GEMINI;
    public static String apiKey = "";
    public static String model = "";
    public static String endpoint = "";

    private static boolean loaded;

    static {
        load();
    }

    private static SharedPreferences prefs() {
        return ApplicationLoader.applicationContext.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
    }

    public static synchronized void load() {
        if (loaded) {
            return;
        }
        SharedPreferences prefs = prefs();
        try {
            provider = Provider.valueOf(prefs.getString("provider", Provider.GEMINI.name()));
        } catch (Exception e) {
            provider = Provider.GEMINI;
        }
        apiKey = prefs.getString("apiKey", "");
        model = prefs.getString("model", "");
        endpoint = prefs.getString("endpoint", "");
        loaded = true;
    }

    public static void setProvider(Provider value) {
        provider = value != null ? value : Provider.GEMINI;
        prefs().edit().putString("provider", provider.name()).apply();
    }

    public static void setApiKey(String value) {
        apiKey = value != null ? value : "";
        prefs().edit().putString("apiKey", apiKey).apply();
    }

    public static void setModel(String value) {
        model = value != null ? value : "";
        prefs().edit().putString("model", model).apply();
    }

    public static void setEndpoint(String value) {
        endpoint = value != null ? value : "";
        prefs().edit().putString("endpoint", endpoint).apply();
    }

    public static boolean isConfigured() {
        return !TextUtils.isEmpty(apiKey);
    }

    public static String getProviderName() {
        switch (provider) {
            case OPENROUTER:
                return "OpenRouter";
            case CUSTOM:
                return "Custom";
            case GEMINI:
            default:
                return "Gemini";
        }
    }

    public static String getEffectiveModel() {
        if (!TextUtils.isEmpty(model)) {
            return model;
        }
        switch (provider) {
            case OPENROUTER:
                return DEFAULT_OPENROUTER_MODEL;
            case CUSTOM:
                return "";
            case GEMINI:
            default:
                return DEFAULT_GEMINI_MODEL;
        }
    }

    public static String getEffectiveEndpoint() {
        if (!TextUtils.isEmpty(endpoint)) {
            return endpoint;
        }
        switch (provider) {
            case OPENROUTER:
                return DEFAULT_OPENROUTER_ENDPOINT;
            case CUSTOM:
                return "";
            case GEMINI:
            default:
                return String.format(GEMINI_ENDPOINT_TEMPLATE, getEffectiveModel());
        }
    }

    public static String keyStatus() {
        if (TextUtils.isEmpty(apiKey)) {
            return "Not set";
        }
        if (apiKey.length() <= 4) {
            return "Set";
        }
        return "Set (…" + apiKey.substring(apiKey.length() - 4) + ")";
    }
}
