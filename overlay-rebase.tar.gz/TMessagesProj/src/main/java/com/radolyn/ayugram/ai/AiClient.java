package com.radolyn.ayugram.ai;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AiClient {
    public interface Callback {
        void onResult(String text);

        void onError(String error);
    }

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private static volatile OkHttpClient client;

    private static OkHttpClient getClient() {
        if (client == null) {
            synchronized (AiClient.class) {
                if (client == null) {
                    client = new OkHttpClient.Builder()
                            .connectTimeout(60, TimeUnit.SECONDS)
                            .readTimeout(60, TimeUnit.SECONDS)
                            .writeTimeout(60, TimeUnit.SECONDS)
                            .build();
                }
            }
        }
        return client;
    }

    public static void complete(String prompt, Callback callback) {
        AiConfig.Provider provider = AiConfig.provider;
        String key = AiConfig.apiKey;
        String model = AiConfig.getEffectiveModel();
        String endpoint = AiConfig.getEffectiveEndpoint();

        if (TextUtils.isEmpty(key)) {
            callback.onError("AI key is not configured. Set it in AyuGram settings.");
            return;
        }
        if (TextUtils.isEmpty(prompt)) {
            callback.onError("Empty prompt.");
            return;
        }

        final Request request;
        try {
            if (provider == AiConfig.Provider.GEMINI) {
                if (TextUtils.isEmpty(endpoint)) {
                    callback.onError("Gemini endpoint is not configured.");
                    return;
                }
                JSONObject body = new JSONObject();
                JSONArray contents = new JSONArray();
                JSONObject content = new JSONObject();
                JSONArray parts = new JSONArray();
                parts.put(new JSONObject().put("text", prompt));
                content.put("parts", parts);
                contents.put(content);
                body.put("contents", contents);

                String url = endpoint + (endpoint.contains("?") ? "&key=" : "?key=") + key;
                request = new Request.Builder()
                        .url(url)
                        .post(RequestBody.create(body.toString(), JSON))
                        .build();
            } else {
                if (TextUtils.isEmpty(endpoint)) {
                    callback.onError("Endpoint is not configured.");
                    return;
                }
                if (TextUtils.isEmpty(model)) {
                    callback.onError("Model is not configured.");
                    return;
                }
                JSONObject body = new JSONObject();
                body.put("model", model);
                JSONArray messages = new JSONArray();
                messages.put(new JSONObject().put("role", "user").put("content", prompt));
                body.put("messages", messages);

                request = new Request.Builder()
                        .url(endpoint)
                        .addHeader("Authorization", "Bearer " + key)
                        .post(RequestBody.create(body.toString(), JSON))
                        .build();
            }
        } catch (Exception e) {
            callback.onError("Failed to build request.");
            return;
        }

        getClient().newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, java.io.IOException e) {
                callback.onError("Network error. Check connection and try again.");
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (Response r = response) {
                    String raw = r.body() != null ? r.body().string() : "";
                    if (!r.isSuccessful()) {
                        callback.onError("Request failed (" + r.code() + "). Check key, model and endpoint.");
                        return;
                    }
                    try {
                        if (provider == AiConfig.Provider.GEMINI) {
                            callback.onResult(parseGemini(raw));
                        } else {
                            callback.onResult(parseChatCompletions(raw));
                        }
                    } catch (Exception e) {
                        callback.onError("Could not parse AI response.");
                    }
                } catch (Exception e) {
                    callback.onError("Failed to read AI response.");
                }
            }
        });
    }

    private static String parseChatCompletions(String raw) throws Exception {
        JSONObject root = new JSONObject(raw);
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) {
            throw new Exception("empty choices");
        }
        JSONObject message = choices.getJSONObject(0).optJSONObject("message");
        if (message == null) {
            throw new Exception("empty message");
        }
        String content = message.optString("content", "").trim();
        if (TextUtils.isEmpty(content)) {
            throw new Exception("empty content");
        }
        return content;
    }

    private static String parseGemini(String raw) throws Exception {
        JSONObject root = new JSONObject(raw);
        JSONArray candidates = root.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            throw new Exception("empty candidates");
        }
        JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
        if (content == null) {
            throw new Exception("empty content");
        }
        JSONArray parts = content.optJSONArray("parts");
        if (parts == null || parts.length() == 0) {
            throw new Exception("empty parts");
        }
        String text = parts.getJSONObject(0).optString("text", "").trim();
        if (TextUtils.isEmpty(text)) {
            throw new Exception("empty text");
        }
        return text;
    }
}
