/*
 * This is the source code of AyuGram for Android.
 *
 * We do not and cannot prevent the use of our code,
 * but be respectful and credit the original author.
 *
 * Copyright @Radolyn, 2023
 */

package com.radolyn.ayugram.sync;

import android.text.TextUtils;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.radolyn.ayugram.AyuConfig;
import com.radolyn.ayugram.AyuUtils;
import com.radolyn.ayugram.sync.models.*;
import com.radolyn.ayugram.utils.AyuGhostUtils;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.telegram.messenger.DispatchQueue;
import org.telegram.messenger.MessagesController;
import org.telegram.messenger.UserConfig;
import org.telegram.tgnet.TLRPC;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class AyuSyncController {

    private static final DispatchQueue queue = new DispatchQueue("AyuSyncController");
    private static AyuSyncController instance;
    private final HashMap<Long, Integer> accounts;
    private final OkHttpClient client;

    public AyuSyncController() {
        accounts = new HashMap<>();

        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder()
                .addInterceptor(new AyuInterceptor());
        client = clientBuilder.build();
    }

    public static void create() {
        if (instance != null && !(instance instanceof AyuSyncControllerEmpty)) {
            return;
        }

        if (!AyuConfig.syncEnabled) {
            AyuSyncWebSocketClient.nullifyInstance();
            instance = new AyuSyncControllerEmpty();
            return;
        }

        instance = new AyuSyncController();

        queue.postRunnable(() -> {
            instance.loadAccounts();
            instance.connect();
        });
    }

    public static AyuSyncController getInstance() {
        if (instance == null) {
            create();
        }

        return instance;
    }

    public static void nullifyInstance() {
        if (instance == null || instance instanceof AyuSyncControllerEmpty) {
            return;
        }

        AyuSyncWebSocketClient.nullifyInstance();

        AyuSyncState.setConnectionState(AyuSyncConnectionState.NotRegistered);

        instance = new AyuSyncControllerEmpty();
    }

    private static void enqueueRetry() {
        queue.postRunnable(() -> {
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            create();
        });
    }

    private void loadAccounts() {
        accounts.clear();

        for (int id = 0; id < UserConfig.MAX_ACCOUNT_COUNT; id++) {
            UserConfig instance = UserConfig.getInstance(id);
            if (instance.isClientActivated()) {
                accounts.put(instance.getClientUserId(), id);
            }
        }
    }

    public void connect() {
        if (TextUtils.isEmpty(AyuSyncConfig.getToken())) {
            nullifyInstance();
            AyuSyncState.setConnectionState(AyuSyncConnectionState.NoToken);
            // don't enqueue retry
            // there will be an attempt when token changed
            return;
        }

        AyuUser self = getSelfForConnect();

        if (self == null) {
            nullifyInstance();
            AyuSyncState.setConnectionState(AyuSyncConnectionState.InvalidToken);
            // retry already enqueued if needed
            return;
        }

        // note for the code explorers:
        // yes, you can nullify this code in smali, but we have server side check,
        // so you can't sync without AyuGram MVP.
        if (!self.isMVP) {
            nullifyInstance();
            AyuSyncState.setConnectionState(AyuSyncConnectionState.NoMVP);
            enqueueRetry();
            return;
        }

        String deviceName = AyuUtils.getDeviceName();
        String deviceIdentifier = AyuUtils.getDeviceIdentifier();

        String url = AyuSyncConfig.getRegisterDeviceURL();
        if (TextUtils.isEmpty(url)) {
            nullifyInstance();
            AyuSyncState.setConnectionState(AyuSyncConnectionState.NotRegistered);
            enqueueRetry();
            return;
        }

        JsonObject obj = new JsonObject();
        obj.addProperty("name", deviceName);
        obj.addProperty("identifier", deviceIdentifier);

        RequestBody body = RequestBody.create(obj.toString(), MediaType.get("application/json; charset=utf-8"));

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        boolean success;
        try (Response response = client.newCall(request).execute()) {
            success = response.isSuccessful();
            Log.d("AyuSync", "Register device status: " + response.code());
            AyuSyncState.setRegisterStatusCode(response.code());
        } catch (IOException e) {
            success = false;
            Log.d("AyuSync", "Failed to register device: " + e.getMessage());
        }

        if (success) {
            AyuSyncState.setConnectionState(AyuSyncConnectionState.Disconnected);
        }

        if (!success) {
            nullifyInstance();
            AyuSyncState.setConnectionState(AyuSyncConnectionState.NotRegistered);
            enqueueRetry();
            return;
        }

        boolean res = AyuSyncWebSocketClient.create();
        Log.d("AyuSync", "WebSocket client created: " + res);
    }

    private AyuUser getSelfForConnect() {
        String url = AyuSyncConfig.getUserDataURL();
        if (TextUtils.isEmpty(url)) {
            return null;
        }
        if (TextUtils.isEmpty(AyuSyncConfig.getToken())) {
            return null;
        }

        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.body() == null) {
                return null;
            }

            Log.d("AyuSync", "Get self status: " + response.code());

            ResponseBody body = response.body();
            if (body == null) {
                return null;
            }

            return new GsonBuilder()
                    .setDateFormat("yyyy-MM-dd'T'HH:mm:ssz")
                    .create()
                    .fromJson(body.string(), AyuUser.class);
        } catch (Exception e) {
            Log.d("AyuSync", "Failed to get self: " + e.getMessage());
            enqueueRetry();
        }

        return null;
    }

    public void forceSync() {
        queue.postRunnable(this::forceSyncInner);
    }

    private void forceSyncInner() {
        // no network on UI thread: forceSync() posts here via queue.postRunnable
        if (TextUtils.isEmpty(AyuSyncConfig.getToken())) {
            return;
        }

        long userId = UserConfig.getInstance(UserConfig.selectedAccount).getClientUserId();

        String url = AyuSyncConfig.getForceSyncURL();
        if (TextUtils.isEmpty(url)) {
            return;
        }

        JsonObject obj = new JsonObject();
        obj.addProperty("userId", userId);
        obj.addProperty("fromDate", 0);

        RequestBody body = RequestBody.create(obj.toString(), MediaType.get("application/json; charset=utf-8"));

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        boolean success;
        try (Response response = client.newCall(request).execute()) {
            if (response.body() == null && !response.isSuccessful()) {
                success = false;
            } else {
                success = response.isSuccessful();
            }
            Log.d("AyuSync", "Force sync status: " + response.code());
        } catch (IOException e) {
            success = false;
            Log.d("AyuSync", "Failed to force sync: " + e.getMessage());
        }
    }

    public void onForceSync(SyncForce req) {
        if (req == null) {
            return;
        }
        Integer accountId = accounts.get(req.userId);
        if (accountId == null) {
            return;
        }

        MessagesController controller = MessagesController.getInstance(accountId);
        if (controller == null) {
            return;
        }

        // ~ sync dialog states
        ArrayList<TLRPC.Dialog> dialogs = controller.getAllDialogs();
        if (dialogs == null) {
            return;
        }
        SyncBatch readsBatchEvent = new SyncBatch();
        readsBatchEvent.userId = req.userId;

        readsBatchEvent.args = new SyncBatch.SyncBatchArgs();

        for (TLRPC.Dialog dialog : dialogs) {
            if (dialog == null) {
                continue;
            }
            long dialogId = dialog.id;
            int dialogReadMaxId = dialog.read_inbox_max_id;

            int unread = controller.getDialogUnreadCount(dialog);

            SyncRead readEv = new SyncRead();
            readEv.userId = req.userId;

            readEv.args = new SyncRead.SyncReadArgs();
            readEv.args.dialogId = dialogId;
            readEv.args.untilId = dialogReadMaxId;
            readEv.args.unread = unread;

            readsBatchEvent.args.events.add(readEv);
        }

        String readEventsMessage = new Gson().toJson(readsBatchEvent);
        AyuSyncWebSocketClient.getInstance().send(readEventsMessage);

        // ~ sync edits history
//        EditedMessageDao editedMessageDao = AyuData.getEditedMessageDao();
//        int editedMessagesCount = editedMessageDao.getSyncCount(req.userId, req.args.fromDate);
//
//        double pages = Math.ceil(editedMessagesCount / 50.0);
//        for (int page = 0; page < pages; ++page) {
//            List edits = editedMessageDao.getForSync(req.userId, req.args.fromDate, page * 50);
//
//            String editsMessage = new Gson().toJson(edits);
//            AyuSyncWebSocketClient.getInstance().send(editsMessage);
//        }

        String finishEvent = new Gson().toJson(new SyncForceFinish());
        AyuSyncWebSocketClient.getInstance().send(finishEvent);
    }

    public void onBatchSync(JsonObject req) {
        for (JsonElement event : req.getAsJsonObject("args").get("events").getAsJsonArray()) {
            invokeHandler(event.getAsJsonObject());
        }
    }

    public void syncRead(int accountId, long dialogId, int untilId) {
        MessagesController controller = MessagesController.getInstance(accountId);
        if (controller == null) {
            return;
        }
        TLRPC.Dialog dialog = controller.getDialog(dialogId);
        if (dialog == null) {
            return;
        }
        int unread = controller.getDialogUnreadCount(dialog);

        SyncRead req = new SyncRead();
        req.userId = UserConfig.getInstance(accountId).getClientUserId();

        req.args = new SyncRead.SyncReadArgs();
        req.args.dialogId = dialogId;
        req.args.untilId = untilId;
        req.args.unread = unread;

        Log.d("AyuSync", "count: " + unread);

        String message = new Gson().toJson(req);

        Log.d("AyuSync", "Sending sync_read: " + message);
        AyuSyncWebSocketClient.getInstance().send(message);
    }

    public void onSyncRead(SyncRead req) {
        if (req == null || req.args == null) {
            return;
        }
        Integer accountId = accounts.get(req.userId);
        if (accountId == null) {
            return;
        }

        MessagesController controller = MessagesController.getInstance(accountId);
        if (controller == null) {
            return;
        }

        TLRPC.Dialog dialog = controller.getDialog(req.args.dialogId);
        if (dialog == null) {
            return;
        }
        if (dialog.unread_count <= req.args.unread) {
            return;
        }

        AyuGhostUtils.markReadLocally(accountId, req.args.dialogId, req.args.untilId, req.args.unread);
    }

    public void invokeHandler(JsonObject req) {
        Log.d("AyuSync", req.toString());

        long userId = req.get("userId").getAsLong();
        String type = req.get("type").getAsString();

        Log.d("AyuSync", "userId: " + userId + ", type: " + type);

        if (!accountExists(userId)) {
            Log.w("AyuSync", "Sync for unknown account: " + userId);
            return;
        }

        switch (type) {
            case "sync_force":
                onForceSync(new Gson().fromJson(req, SyncForce.class));
                break;
            case "sync_batch":
                onBatchSync(req);
                break;
            case "sync_read":
                onSyncRead(new Gson().fromJson(req, SyncRead.class));
                break;
            default:
                Log.d("AyuSync", "Unknown sync type: " + type);
                break;
        }
    }

    public boolean accountExists(long userId) {
        return userId == 0 || accounts.containsKey(userId);
    }
}
