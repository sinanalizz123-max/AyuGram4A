package com.radolyn.ayugram.transcribe;

import java.io.File;

public interface TranscribeEngine {
    String transcribe(File audio) throws Exception;

    boolean isAvailable();
}
