package com.radolyn.ayugram.transcribe;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.FileLog;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ModelDownloader {
    public interface ProgressCallback {
        void onProgress(long downloadedBytes, long totalBytes);

        void onDone(File file);

        void onError(String error);
    }

    private static final ExecutorService executor = Executors.newCachedThreadPool();

    public static long download(Context ctx, String url, File dest, String expectedSha256OrNull, ProgressCallback callback) {
        Context appCtx = ctx.getApplicationContext();
        try {
            File parent = dest.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            if (dest.exists()) {
                dest.delete();
            }
            DownloadManager dm = (DownloadManager) appCtx.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) {
                postError(callback, "DownloadManager unavailable");
                return -1;
            }
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setDestinationUri(Uri.fromFile(dest));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            long downloadId = dm.enqueue(request);
            executor.execute(() -> pollProgress(appCtx, dm, downloadId, dest, expectedSha256OrNull, callback));
            return downloadId;
        } catch (Exception e) {
            FileLog.e(e);
            postError(callback, e.getMessage());
            return -1;
        }
    }

    public static void cancel(Context ctx, long downloadId) {
        try {
            DownloadManager dm = (DownloadManager) ctx.getApplicationContext().getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.remove(downloadId);
            }
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    private static void pollProgress(Context ctx, DownloadManager dm, long downloadId, File dest, String expectedSha256OrNull, ProgressCallback callback) {
        DownloadManager.Query query = new DownloadManager.Query().setFilterById(downloadId);
        boolean finished = false;
        while (!finished) {
            Cursor cursor = null;
            try {
                cursor = dm.query(query);
                if (cursor == null || !cursor.moveToFirst()) {
                    postError(callback, "Download cancelled");
                    return;
                }
                int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                long downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    finished = true;
                } else if (status == DownloadManager.STATUS_FAILED) {
                    int reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                    postError(callback, "Download failed (" + reason + ")");
                    return;
                } else {
                    postProgress(callback, downloaded, total);
                }
            } catch (Exception e) {
                FileLog.e(e);
                postError(callback, e.getMessage());
                return;
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
            if (!finished) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ignored) {
                    postError(callback, "Download cancelled");
                    return;
                }
            }
        }
        if (expectedSha256OrNull != null && !expectedSha256OrNull.isEmpty()) {
            try {
                String actual = sha256(dest);
                if (!expectedSha256OrNull.equalsIgnoreCase(actual)) {
                    dest.delete();
                    postError(callback, "Checksum mismatch");
                    return;
                }
            } catch (Exception e) {
                FileLog.e(e);
                dest.delete();
                postError(callback, "Checksum failed");
                return;
            }
        } else {
            // TODO: pin known SHA-256 hashes per model variant and verify by default
        }
        postDone(callback, dest);
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                digest.update(buf, 0, n);
            }
        }
        byte[] hash = digest.digest();
        StringBuilder sb = new StringBuilder(hash.length * 2);
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static void postProgress(ProgressCallback callback, long downloaded, long total) {
        if (callback == null) {
            return;
        }
        AndroidUtilities.runOnUIThread(() -> callback.onProgress(downloaded, total));
    }

    private static void postDone(ProgressCallback callback, File file) {
        if (callback == null) {
            return;
        }
        AndroidUtilities.runOnUIThread(() -> callback.onDone(file));
    }

    private static void postError(ProgressCallback callback, String error) {
        if (callback == null) {
            return;
        }
        AndroidUtilities.runOnUIThread(() -> callback.onError(error));
    }
}
