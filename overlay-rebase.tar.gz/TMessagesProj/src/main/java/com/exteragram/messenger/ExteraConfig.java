/*

 This is the source code of exteraGram for Android.

 We do not and cannot prevent the use of our code,
 but be respectful and credit the original author.

 Copyright @immat0x1, 2023

*/

package com.exteragram.messenger;

import android.app.Activity;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.exteragram.messenger.camera.CameraXUtils;
import com.exteragram.messenger.icons.BaseIconSet;
import com.exteragram.messenger.icons.EmptyIconSet;
import com.exteragram.messenger.icons.SolarIconSet;
import com.radolyn.ayugram.AyuConstants;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.BuildVars;
import org.telegram.messenger.FileLog;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.SharedConfig;
import org.telegram.messenger.UserConfig;
import org.telegram.tgnet.TLRPC;

import java.util.Arrays;

public class ExteraConfig {

    private static final Object sync = new Object();

    // Appearance
    public static float avatarCorners;
    public static boolean hideActionBarStatus;
    public static boolean hideAllChats;
    public static boolean tabCounter;
    public static boolean centerTitle;
    public static int tabIcons; // icons with titles - 0, titles - 1, icons - 2
    public static int tabStyle;
    public static int titleText;

    public static boolean useSolarIcons;

    public static boolean squareFab;
    public static boolean forceBlur;
    public static boolean forceSnow;
    public static boolean useSystemFonts;
    public static boolean newSwitchStyle;
    public static boolean disableDividers;
    public static boolean useLNavigation;

    public static int eventType;
    public static boolean alternativeOpenAnimation;
    public static boolean changeStatus, newGroup, newSecretChat, newChannel, contacts, calls, peopleNearby, archivedChats, savedMessages, scanQr;

    // General
    public static int cameraType;
    public static boolean useCameraXOptimizedMode;
    public static int cameraResolution;

    public static boolean disableNumberRounding;
    public static boolean formatTimeWithSeconds;
    public static int tabletMode;

    public static int downloadSpeedBoost;
    public static boolean uploadSpeedBoost;

    public static boolean hidePhoneNumber;
    public static int showIdAndDc;

    public static boolean archiveOnPull;
    public static boolean disableUnarchiveSwipe;

    // Chats
    public static float stickerSize;

    public static int stickerShape;

    public static boolean hideStickerTime;
    public static boolean unlimitedRecentStickers;
    public static boolean hideCategories;

    public static int doubleTapAction;
    public static int doubleTapActionOutOwner;

    public static int doubleTapSeekDuration;
    public static int bottomButton;
    public static boolean hideKeyboardOnScroll;
    public static boolean permissionsShortcut;
    public static boolean administratorsShortcut;
    public static boolean membersShortcut;
    public static boolean recentActionsShortcut;
    public static boolean disableJumpToNextChannel;
    public static boolean showActionTimestamps;
    public static boolean hideShareButton;
    public static boolean showCopyPhotoButton;
    public static boolean showClearButton;
    public static boolean showSaveMessageButton;
    public static boolean showDetailsButton;
    public static boolean showReportButton;
    public static boolean showHistoryButton;
    public static boolean addCommaAfterMention;

    public static int sendPhotosQuality;
    public static boolean hideCameraTile;
    public static boolean hidePhotoCounter;

    public static boolean staticZoom;
    public static int videoMessagesCamera; // front rear ask
    public static boolean rememberLastUsedCamera;
    public static boolean pauseOnMinimize;
    public static boolean disablePlayback;

    // Updates
    public static long lastUpdateCheckTime;
    public static long updateScheduleTimestamp;
    public static boolean checkUpdatesOnLaunch;

    // Other
    private static final long[] OFFICIAL_CHANNELS = {1233768168, 1524581881, 1571726392, 1632728092, 1638754701, 1779596027, 1172503281, 1877362358};
    private static final long[] DEVS = {963080346, 1282540315, 1374434073, 388099852, 1972014627, 168769611, 480000401, 5307590670L, 639891381, 1773117711, 5330087923L, 666154369};
    public static long channelToSave;
    public static String targetLanguage;
    public static final CharSequence[] supportedLanguages = new CharSequence[]{
            "Arabic (AR)", "Azerbaijani (AZ)", "Belarusian (BE)", "Catalan (CA)", "Chinese (ZH)",
            "Croatian (HR)", "Czech (CS)", "Dutch (NL)", "English (EN)", "Finnish (FI)",
            "French (FR)", "German (DE)", "Hungarian (HU)", "Indonesian (IN)", "Italian (IT)", "Japanese (JA)",
            "Korean (KO)", "Malay (MS)", "Norwegian (NO)", "Persian (FA)", "Polish (PL)",
            "Portuguese (PT)", "Russian (RU)", "Serbian (SR)", "Slovak (SK)",
            "Spanish (ES)", "Swedish (SV)", "Turkish (TR)", "Ukrainian (UK)", "Uzbek (UZ)"
    };
    public static int voiceHintShowcases;
    public static boolean useGoogleCrashlytics;
    public static boolean useGoogleAnalytics;

    private static boolean configLoaded;

    public static SharedPreferences preferences;
    public static SharedPreferences.Editor editor;

    static {
        try {
            loadConfig();
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    public static void loadConfig() {
        synchronized (sync) {
            if (configLoaded) {
                return;
            }
            try {
                if (ApplicationLoader.applicationContext == null) {
                    return;
                }
                preferences = ApplicationLoader.applicationContext.getSharedPreferences("exteraconfig", Activity.MODE_PRIVATE);
                if (preferences == null) {
                    return;
                }
                editor = preferences.edit();

            // General
            cameraType = preferences.getInt("cameraType", CameraXUtils.isCameraXSupported() ? 1 : 0);
            useCameraXOptimizedMode = preferences.getBoolean("useCameraXOptimizedMode", SharedConfig.getDevicePerformanceClass() != SharedConfig.PERFORMANCE_CLASS_HIGH);
            cameraResolution = preferences.getInt("cameraResolution", CameraXUtils.getCameraResolution());

            disableNumberRounding = preferences.getBoolean("disableNumberRounding", false);
            formatTimeWithSeconds = preferences.getBoolean("formatTimeWithSeconds", false);
            tabletMode = preferences.getInt("tabletMode", 0);

            downloadSpeedBoost = preferences.getInt("downloadSpeedBoost", 0);
            uploadSpeedBoost = preferences.getBoolean("uploadSpeedBoost", false);

            hidePhoneNumber = preferences.getBoolean("hidePhoneNumber", false);
            showIdAndDc = preferences.getInt("showIdAndDc", 2);

            archiveOnPull = preferences.getBoolean("archiveOnPull", false);
            disableUnarchiveSwipe = preferences.getBoolean("disableUnarchiveSwipe", true);

            // Appearance
            avatarCorners = preferences.getFloat("avatarCorners", 30.0f);
            hideActionBarStatus = preferences.getBoolean("hideActionBarStatus", false);
            hideAllChats = preferences.getBoolean("hideAllChats", false);
            centerTitle = preferences.getBoolean("centerTitle", false);
            tabCounter = preferences.getBoolean("tabCounter", true);
            tabIcons = preferences.getInt("tabIcons", 1);
            tabStyle = preferences.getInt("tabStyle", 4);
            titleText = preferences.getInt("titleText", 2);

            useSolarIcons = preferences.getBoolean("useSolarIcons", true);

            squareFab = preferences.getBoolean("squareFab", true);
            forceBlur = preferences.getBoolean("forceBlur", true);
            forceSnow = preferences.getBoolean("forceSnow", false);
            useSystemFonts = preferences.getBoolean("useSystemFonts", true);
            newSwitchStyle = preferences.getBoolean("newSwitchStyle", true);
            disableDividers = preferences.getBoolean("disableDividers", false);
            useLNavigation = preferences.getBoolean("useLNavigation", false);

            eventType = preferences.getInt("eventType", 0);
            alternativeOpenAnimation = preferences.getBoolean("alternativeOpenAnimation", true);

            changeStatus = preferences.getBoolean("changeStatus", true);
            newGroup = preferences.getBoolean("newGroup", true);
            newSecretChat = preferences.getBoolean("newSecretChat", false);
            newChannel = preferences.getBoolean("newChannel", false);
            contacts = preferences.getBoolean("contacts", true);
            calls = preferences.getBoolean("calls", true);
            peopleNearby = preferences.getBoolean("peopleNearby", false);
            archivedChats = preferences.getBoolean("archivedChats", true);
            savedMessages = preferences.getBoolean("savedMessages", true);
            scanQr = preferences.getBoolean("scanQr", true);

            // Chats
            stickerSize = preferences.getFloat("stickerSize", 14.0f);
            stickerShape = preferences.getInt("stickerShape", 1);

            hideStickerTime = preferences.getBoolean("hideStickerTime", false);
            unlimitedRecentStickers = preferences.getBoolean("unlimitedRecentStickers", false);
            hideCategories = preferences.getBoolean("hideCategories", true);

            doubleTapAction = preferences.getInt("doubleTapAction", 1);
            doubleTapActionOutOwner = preferences.getInt("doubleTapActionOutOwner", 1);

            bottomButton = preferences.getInt("bottomButton", 2);
            hideKeyboardOnScroll = preferences.getBoolean("hideKeyboardOnScroll", true);
            permissionsShortcut = preferences.getBoolean("permissionsShortcut", false);
            administratorsShortcut = preferences.getBoolean("administratorsShortcut", false);
            membersShortcut = preferences.getBoolean("membersShortcut", false);
            recentActionsShortcut = preferences.getBoolean("recentActionsShortcut", true);
            disableJumpToNextChannel = preferences.getBoolean("disableJumpToNextChannel", false);
            showActionTimestamps = preferences.getBoolean("showActionTimestamps", true);
            hideShareButton = preferences.getBoolean("hideShareButton", true);
            showDetailsButton = preferences.getBoolean("showDetailsButton", false);
            showSaveMessageButton = preferences.getBoolean("showSaveMessageButton", false);
            showCopyPhotoButton = preferences.getBoolean("showCopyPhotoButton", true);
            showClearButton = preferences.getBoolean("showClearButton", true);
            showReportButton = preferences.getBoolean("showReportButton", true);
            showHistoryButton = preferences.getBoolean("showHistoryButton", false);

            addCommaAfterMention = preferences.getBoolean("addCommaAfterMention", true);

            sendPhotosQuality = preferences.getInt("sendPhotosQuality", 2);
            hidePhotoCounter = preferences.getBoolean("hidePhotoCounter", true);
            hideCameraTile = preferences.getBoolean("hideCameraTile", true);

            staticZoom = preferences.getBoolean("staticZoom", false);
            videoMessagesCamera = preferences.getInt("videoMessagesCamera", 0);
            rememberLastUsedCamera = preferences.getBoolean("rememberLastUsedCamera", false);
            pauseOnMinimize = preferences.getBoolean("pauseOnMinimize", true);
            doubleTapSeekDuration = preferences.getInt("doubleTapSeekDuration", 1);
            disablePlayback = preferences.getBoolean("disablePlayback", true);

            // Updates
            lastUpdateCheckTime = preferences.getLong("lastUpdateCheckTime", 0);
            updateScheduleTimestamp = preferences.getLong("updateScheduleTimestamp", 0);
            checkUpdatesOnLaunch = preferences.getBoolean("checkUpdatesOnLaunch", true);

            // Other
            channelToSave = preferences.getLong("channelToSave", 0);
            try {
                targetLanguage = preferences.getString("targetLanguage", (String) supportedLanguages[8]);
            } catch (Exception e) {
                FileLog.e(e);
            }
            if (targetLanguage == null) {
                targetLanguage = (String) supportedLanguages[8];
            }
            voiceHintShowcases = preferences.getInt("voiceHintShowcases", 0);
            useGoogleCrashlytics = preferences.getBoolean("useGoogleCrashlytics", BuildVars.isBetaApp());
            useGoogleAnalytics = preferences.getBoolean("useGoogleAnalytics", BuildVars.isBetaApp());

            configLoaded = true;
            } catch (Exception e) {
                FileLog.e(e);
            }
        }
    }

    public static boolean isExtera(TLRPC.Chat chat) {
        if (chat == null) {
            return false;
        }
        try {
            if (Arrays.stream(OFFICIAL_CHANNELS).anyMatch(id -> id == chat.id)) {
                return true;
            }
            long[] official = AyuConstants.OFFICIAL_CHANNELS;
            return official != null && Arrays.stream(official).anyMatch(id -> id == chat.id);
        } catch (Exception e) {
            FileLog.e(e);
            return false;
        }
    }

    public static boolean isExteraDev(TLRPC.User user) {
        if (user == null) {
            return false;
        }
        try {
            if (Arrays.stream(DEVS).anyMatch(id -> id == user.id)) {
                return true;
            }
            long[] devs = AyuConstants.DEVS;
            return devs != null && Arrays.stream(devs).anyMatch(id -> id == user.id);
        } catch (Exception e) {
            FileLog.e(e);
            return false;
        }
    }

    public static int getAvatarCorners(float size) {
        return getAvatarCorners(size, false);
    }

    public static int getAvatarCorners(float size, boolean toPx) {
        if (avatarCorners == 0) {
            return 0;
        }
        return (int) (avatarCorners * (size / 56.0f) * (toPx ? 1 : AndroidUtilities.density));
    }

    private static void putBoolean(String key, boolean value) {
        try {
            if (preferences == null) {
                return;
            }
            preferences.edit().putBoolean(key, value).apply();
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    private static void putLong(String key, long value) {
        try {
            if (preferences == null) {
                return;
            }
            preferences.edit().putLong(key, value).apply();
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    public static void toggleDrawerElements(int id) {
        switch (id) {
            case 1:
                putBoolean("newGroup", newGroup ^= true);
                break;
            case 2:
                putBoolean("newSecretChat", newSecretChat ^= true);
                break;
            case 3:
                putBoolean("newChannel", newChannel ^= true);
                break;
            case 4:
                putBoolean("contacts", contacts ^= true);
                break;
            case 5:
                putBoolean("calls", calls ^= true);
                break;
            case 6:
                putBoolean("peopleNearby", peopleNearby ^= true);
                break;
            case 7:
                putBoolean("archivedChats", archivedChats ^= true);
                break;
            case 8:
                putBoolean("savedMessages", savedMessages ^= true);
                break;
            case 9:
                putBoolean("scanQr", scanQr ^= true);
                break;
            case 10:
                putBoolean("changeStatus", changeStatus ^= true);
                break;
        }
        try {
            NotificationCenter.getInstance(UserConfig.selectedAccount).postNotificationName(NotificationCenter.mainUserInfoChanged);
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    public static void setChannelToSave(long id) {
        channelToSave = id;
        putLong("channelToSave", id);
    }

    public static void toggleLogging() {
        try {
            if (ApplicationLoader.applicationContext == null) {
                return;
            }
            ApplicationLoader.applicationContext.getSharedPreferences("systemConfig", Activity.MODE_PRIVATE).edit().putBoolean("logsEnabled", BuildVars.LOGS_ENABLED ^= true).apply();
            if (!BuildVars.LOGS_ENABLED) FileLog.cleanupLogs();
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    public static boolean getLogging() {
        try {
            if (ApplicationLoader.applicationContext == null) {
                return false;
            }
            return ApplicationLoader.applicationContext.getSharedPreferences("systemConfig", Activity.MODE_PRIVATE).getBoolean("logsEnabled", false); //BuildVars.DEBUG_VERSION);
        } catch (Exception e) {
            FileLog.e(e);
            return false;
        }
    }

    public static String getCurrentLangName() {
        try {
            if (targetLanguage == null || !targetLanguage.contains("(")) {
                return targetLanguage != null ? targetLanguage : "English";
            }
            return targetLanguage.substring(0, targetLanguage.indexOf("(") - 1);
        } catch (Exception e) {
            FileLog.e(e);
            return targetLanguage != null ? targetLanguage : "English";
        }
    }

    public static String getCurrentLangCode() {
        try {
            if (targetLanguage == null || !targetLanguage.contains("(") || !targetLanguage.contains(")")) {
                return "EN";
            }
            return targetLanguage.substring(targetLanguage.indexOf("(") + 1, targetLanguage.indexOf(")"));
        } catch (Exception e) {
            FileLog.e(e);
            return "EN";
        }
    }

    public static BaseIconSet getIconPack() {
        return useSolarIcons ? new SolarIconSet() : new EmptyIconSet();
    }

    public static int getPhotosQuality() {
        switch (sendPhotosQuality) {
            case 0:
                return 800;
            case 1:
            default:
                return 1280;
            case 2:
                return 2560;
        }
    }

    public static int getDoubleTapSeekDuration() {
        switch(doubleTapSeekDuration) {
            case 0:
            case 1:
            case 2:
                return (doubleTapSeekDuration + 1) * 5000;
            default:
                return 30000;
        }
    }

    public static void clearPreferences() {
        try {
            configLoaded = false;
            if (preferences != null) {
                try {
                    preferences.edit().clear().apply();
                } catch (Exception e) {
                    FileLog.e(e);
                }
            }
            ExteraConfig.loadConfig();
        } catch (Exception e) {
            FileLog.e(e);
        }
    }
}
