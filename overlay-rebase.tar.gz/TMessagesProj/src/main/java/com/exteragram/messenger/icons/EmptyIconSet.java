/*

 This is the source code of exteraGram for Android.

 We do not and cannot prevent the use of our code,
 but be respectful and credit the original author.

 Copyright @immat0x1, 2023

*/

package com.exteragram.messenger.icons;

public class EmptyIconSet extends BaseIconSet {
    public EmptyIconSet() {
        iconPack = new android.util.SparseIntArray();
    }
}
