/*

 This is the source code of exteraGram for Android.

 We do not and cannot prevent the use of our code,
 but be respectful and credit the original author.

 Copyright @immat0x1, 2023

*/

package com.exteragram.messenger.icons;

import android.util.SparseIntArray;

import org.telegram.messenger.R;

public class IconSetsController {
    public static final SparseIntArray solar = new SparseIntArray();

    static {
    }
}
